let global = {
    AANTAL_HORIZONTAAL: 4,
    AANTAL_VERTICAAL: 3,
    AANTAL_KAARTEN: 6,
    SELECTED: []
};
const setup = () => {
    let afbeeldingen = [];
    for(let i = 0; i < global.AANTAL_KAARTEN; i++){
        afbeeldingen.push(`images/kaart${i+1}.jpg`)
        afbeeldingen.push(`images/kaart${i+1}.jpg`)
    }

    console.log(afbeeldingen);
    let berekening = global.AANTAL_HORIZONTAAL*150+20;
    document.getElementById("grid").style.width = berekening + "px";
    let berekening2 = global.AANTAL_VERTICAAL*150+20;
    document.getElementById("grid").style.height = berekening2 + "px";
    afbeeldingen = shuffleArray(afbeeldingen);
    console.log(afbeeldingen);
    for (let i = 0; i < afbeeldingen.length; i++){
        let para = document.createElement("img");
        let div = document.getElementById("grid");
        let divAdd = document.createElement("div");
        para.src = afbeeldingen[i];
        para.alt = "hiddenImage";
        para.classList.add('hiddenImage');
        divAdd.appendChild(para);
        div.appendChild(divAdd);
        para.addEventListener("click", () => {
        removeCover(para);
        });
    }

}

const removeCover = (para) => {
    para.classList.remove('hiddenImage');
    if(global.SELECTED.length === 2){
        console.log(global.SELECTED);
        return
    }
    global.SELECTED.push(para);
    /*if(global.AFBEELDING_1 === null || global.AFBEELDING_2 === null){
        if(global.AFBEELDING_1 === null){
            global.AFBEELDING_1 = para;
        }
        else if (global.AFBEELDING_2 === null){
            global.AFBEELDING_2 = para;
        }
    }
    console.log(global.AFBEELDING_1);
    console.log(global.AFBEELDING_2);
    if(global.AFBEELDING_1 !== null && global.AFBEELDING_2 !== null ){
        if(global.AFBEELDING_1.src === global.AFBEELDING_2.src){
            console.log("success")
        }
        else{
            global.AFBEELDING_1 = null;
            global.AFBEELDING_2 = null;
        }
    }*/

}
const removeCard = (divImage) =>{
    let div = document.getElementById("grid");
    div.removeChild(divImage);
};

const shuffleArray = (array) => {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}
window.addEventListener("load", setup);